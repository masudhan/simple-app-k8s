#!/bin/bash

kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/v0.13.12/config/manifests/metallb-native.yaml  

sleep 60 

kubectl apply -f metallb/metallb.yaml

kubectl create ns ingress-nginx 

helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx  

helm repo update

kubectl apply -f nginx-ingress-controller/sitemaintenance.yaml

helm install ingress-nginx ingress-nginx/ingress-nginx -n ingress-nginx --values nginx-ingress-controller/ingress-nginx-values.yaml 

sleep 60 

kubectl apply -f test502/502-deployment.yaml -f test502/502-service.yaml -f test502/502-ingress.yaml 
kubectl apply -f test503/503-deployment.yaml -f test503/503-service.yaml -f test503/503-ingress.yaml 
